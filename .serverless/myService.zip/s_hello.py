import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='crix11s',
    application_name='crix11s-app',
    app_uid='zsygBDJbh0FyYghZ08',
    org_uid='944bf4ec-8d31-44e7-ad51-e221b321b097',
    deployment_uid='8bec016b-a816-46d8-98b9-83915ef8136c',
    service_name='myService',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.0.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'myService-dev-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
