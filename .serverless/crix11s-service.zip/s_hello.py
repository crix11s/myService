import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='crix11s',
    application_name='crix11s-app',
    app_uid='zsygBDJbh0FyYghZ08',
    org_uid='944bf4ec-8d31-44e7-ad51-e221b321b097',
    deployment_uid='3123c2d0-6711-4445-8e15-07910b4c3b9e',
    service_name='crix11s-service',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.0.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'crix11s-service-dev-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
